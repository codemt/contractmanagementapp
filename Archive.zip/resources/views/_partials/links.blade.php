<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="theme-color" content="#d9230f">

<link rel="icon" type="image/png" href="{{ asset('favicon.ico')}}">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400italic,500,700">

<link rel="stylesheet" href="{{ asset('css/vendor.min.css')}}">
<link rel="stylesheet" href="{{ asset('css/elevator.min.css')}}">
<link rel="stylesheet" href="{{ asset('css/application.min.css')}}">
<link rel="stylesheet" href="{{ asset('css/parsley_validation.css')}}">
<meta name="csrf-token" content="{{ csrf_token() }}">
{{-- <link rel="stylesheet" href="{{ asset('css/myStyle.min.css')}}"> --}}
