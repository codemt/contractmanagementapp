<div class="layout-footer">
    <div class="layout-footer-body">
        <small class="copyright">2018 &copy; Icon Control System
            <a href="https://fourbrothers.co.in/" target=_blank class="hidden-xs">
                Made by Fourbrothers Software Solution
            </a>
        </small>
        <small class="version">
            <a href="https://fourbrothers.co.in/" target=_blank class="visible-xs">
                Made by FBSS
            </a>
        </small>
    </div>
</div>
