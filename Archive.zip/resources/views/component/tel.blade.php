
    <select id="demo-select2-5" class="form-control">
        <option data-country-code="+1" value="us">United States +1</option>
        <option data-country-code="+93" value="af">Afghanistan (‫افغانستان‬‎) +93</option>
        <option data-country-code="+355" value="al">Albania (Shqipëri) +355</option>
        <option data-country-code="+213" value="dz">Algeria +213</option>
        <option data-country-code="+1684" value="as">American Samoa +1684</option>
        <option data-country-code="+376" value="ad">Andorra +376</option>
        <option data-country-code="+244" value="ao">Angola +244</option>
        <option data-country-code="+1264" value="ai">Anguilla +1264</option>
        <option data-country-code="+1268" value="ag">Antigua &amp; Barbuda +1268</option>
        <option data-country-code="+54" value="ar">Argentina +54</option>
        <option data-country-code="+374" value="am">Armenia (Հայաստան) +374</option>
        <option data-country-code="+297" value="aw">Aruba +297</option>
        <option data-country-code="+61" value="au">Australia +61</option>
        <option data-country-code="+43" value="at">Austria (Österreich) +43</option>
        <option data-country-code="+994" value="az">Azerbaijan (Azərbaycan) +994</option>
        <option data-country-code="+1242" value="bs">Bahamas +1242</option>
        <option data-country-code="+973" value="bh">Bahrain (‫البحرين‬‎) +973</option>
        <option data-country-code="+880" value="bd">Bangladesh (বাংলাদেশ) +880</option>
        <option data-country-code="+1246" value="bb">Barbados +1246</option>
        <option data-country-code="+375" value="by">Belarus (Беларусь) +375</option>
        <option data-country-code="+32" value="be">Belgium +32</option>
        <option data-country-code="+501" value="bz">Belize +501</option>
        <option data-country-code="+229" value="bj">Benin (Bénin) +229</option>
        <option data-country-code="+1441" value="bm">Bermuda +1441</option>
        <option data-country-code="+975" value="bt">Bhutan (འབྲུག) +975</option>
        <option data-country-code="+591" value="bo">Bolivia +591</option>
        <option data-country-code="+387" value="ba">Bosnia &amp; Herzegovina (Босна и Херцеговина) +387</option>
        <option data-country-code="+267" value="bw">Botswana +267</option>
        <option data-country-code="+55" value="br">Brazil (Brasil) +55</option>
        <option data-country-code="+246" value="io">British Indian Ocean Territory +246</option>
        <option data-country-code="+1284" value="vg">British Virgin Islands +1284</option>
        <option data-country-code="+673" value="bn">Brunei +673</option>
        <option data-country-code="+359" value="bg">Bulgaria (България) +359</option>
        <option data-country-code="+226" value="bf">Burkina Faso +226</option>
        <option data-country-code="+257" value="bi">Burundi (Uburundi) +257</option>
        <option data-country-code="+855" value="kh">Cambodia (កម្ពុជា) +855</option>
        <option data-country-code="+237" value="cm">Cameroon (Cameroun) +237</option>
        <option data-country-code="+1" value="ca">Canada +1</option>
        <option data-country-code="+238" value="cv">Cabo Verde (Kabu Verdi) +238</option>
        <option data-country-code="+236" value="cf">Central African Republic (République centrafricaine) +236</option>
        <option data-country-code="+235" value="td">Chad (Tchad) +235</option>
        <option data-country-code="+56" value="cl">Chile +56</option>
        <option data-country-code="+86" value="cn">China (中国) +86</option>
        <option data-country-code="+57" value="co">Colombia +57</option>
        <option data-country-code="+269" value="km">Comoros (‫جزر القمر‬‎) +269</option>
        <option data-country-code="+243" value="cg">Congo (DRC) (Jamhuri ya Kidemokrasia ya Kongo) +243</option>
        <option data-country-code="+242" value="cg">Congo (Republic) (Congo-Brazzaville) +242</option>
        <option data-country-code="+682" value="ck">Cook Islands +682</option>
        <option data-country-code="+506" value="cr">Costa Rica +506</option>
        <option data-country-code="+225" value="ci">Côte d&#x27;Ivoire +225</option>
        <option data-country-code="+385" value="hr">Croatia (Hrvatska) +385</option>
        <option data-country-code="+53" value="cu">Cuba +53</option>
        <option data-country-code="+599" value="cw">Curaçao +599</option>
        <option data-country-code="+357" value="cy">Cyprus (Κύπρος) +357</option>
        <option data-country-code="+420" value="cz">Czech Republic (Česká republika) +420</option>
        <option data-country-code="+45" value="dk">Denmark (Danmark) +45</option>
        <option data-country-code="+253" value="dj">Djibouti +253</option>
        <option data-country-code="+1767" value="do">Dominica +1767</option>
        <option data-country-code="+1809" value="do">Dominican Republic (República Dominicana) +1809</option>
        <option data-country-code="+593" value="ec">Ecuador +593</option>
        <option data-country-code="+20" value="eg">Egypt (‫مصر‬‎) +20</option>
        <option data-country-code="+503" value="sv">El Salvador +503</option>
        <option data-country-code="+240" value="gq">Equatorial Guinea (Guinea Ecuatorial) +240</option>
        <option data-country-code="+291" value="er">Eritrea +291</option>
        <option data-country-code="+372" value="ee">Estonia (Eesti) +372</option>
        <option data-country-code="+251" value="et">Ethiopia +251</option>
        <option data-country-code="+500" value="fk">Falkland Islands (Islas Malvinas) +500</option>
        <option data-country-code="+298" value="fo">Faroe Islands (Føroyar) +298</option>
        <option data-country-code="+679" value="fj">Fiji +679</option>
        <option data-country-code="+358" value="fi">Finland (Suomi) +358</option>
        <option data-country-code="+33" value="fr">France +33</option>
        <option data-country-code="+594" value="gf">French Guiana (Guyane française) +594</option>
        <option data-country-code="+689" value="pf">French Polynesia (Polynésie française) +689</option>
        <option data-country-code="+241" value="ga">Gabon +241</option>
        <option data-country-code="+220" value="gm">Gambia +220</option>
        <option data-country-code="+995" value="gs">Georgia (საქართველო) +995</option>
        <option data-country-code="+49" value="de">Germany (Deutschland) +49</option>
        <option data-country-code="+233" value="gh">Ghana (Gaana) +233</option>
        <option data-country-code="+350" value="gi">Gibraltar +350</option>
        <option data-country-code="+30" value="gr">Greece (Ελλάδα) +30</option>
        <option data-country-code="+299" value="gl">Greenland (Kalaallit Nunaat) +299</option>
        <option data-country-code="+1473" value="gd">Grenada +1473</option>
        <option data-country-code="+590" value="gp">Guadeloupe +590</option>
        <option data-country-code="+1671" value="gu">Guam +1671</option>
        <option data-country-code="+502" value="gt">Guatemala +502</option>
        <option data-country-code="+224" value="pg">Guinea (Guinée) +224</option>
        <option data-country-code="+245" value="gw">Guinea-Bissau (Guiné-Bissau) +245</option>
        <option data-country-code="+592" value="gy">Guyana +592</option>
        <option data-country-code="+509" value="ht">Haiti +509</option>
        <option data-country-code="+504" value="hn">Honduras +504</option>
        <option data-country-code="+852" value="hk">Hong Kong (香港) +852</option>
        <option data-country-code="+36" value="hu">Hungary (Magyarország) +36</option>
        <option data-country-code="+354" value="is">Iceland (Ísland) +354</option>
        <option data-country-code="+91" value="in" selected>India (भारत) +91</option>
        <option data-country-code="+62" value="id">Indonesia +62</option>
        <option data-country-code="+98" value="ir">Iran (‫ایران‬‎) +98</option>
        <option data-country-code="+964" value="iq">Iraq (‫العراق‬‎) +964</option>
        <option data-country-code="+353" value="ie">Ireland +353</option>
        <option data-country-code="+972" value="il">Israel (‫ישראל‬‎) +972</option>
        <option data-country-code="+39" value="it">Italy (Italia) +39</option>
        <option data-country-code="+1876" value="jm">Jamaica +1876</option>
        <option data-country-code="+81" value="jp">Japan (日本) +81</option>
        <option data-country-code="+962" value="jo">Jordan (‫الأردن‬‎) +962</option>
        <option data-country-code="+7" value="kz">Kazakhstan (Казахстан) +7</option>
        <option data-country-code="+254" value="ke">Kenya +254</option>
        <option data-country-code="+686" value="ki">Kiribati +686</option>
        <option data-country-code="+965" value="kw">Kuwait (‫الكويت‬‎) +965</option>
        <option data-country-code="+996" value="kg">Kyrgyzstan (Кыргызстан) +996</option>
        <option data-country-code="+856" value="la">Laos (ລາວ) +856</option>
        <option data-country-code="+371" value="lv">Latvia (Latvija) +371</option>
        <option data-country-code="+961" value="lb">Lebanon (‫لبنان‬‎) +961</option>
        <option data-country-code="+266" value="ls">Lesotho +266</option>
        <option data-country-code="+231" value="lr">Liberia +231</option>
        <option data-country-code="+218" value="ly">Libya (‫ليبيا‬‎) +218</option>
        <option data-country-code="+423" value="li">Liechtenstein +423</option>
        <option data-country-code="+370" value="lt">Lithuania (Lietuva) +370</option>
        <option data-country-code="+352" value="lu">Luxembourg +352</option>
        <option data-country-code="+853" value="mo">Macau (澳門) +853</option>
        <option data-country-code="+389" value="mk">Macedonia (FYROM) (Македонија) +389</option>
        <option data-country-code="+261" value="mg">Madagascar (Madagasikara) +261</option>
        <option data-country-code="+265" value="mw">Malawi +265</option>
        <option data-country-code="+60" value="my">Malaysia +60</option>
        <option data-country-code="+960" value="mv">Maldives +960</option>
        <option data-country-code="+223" value="so">Mali +223</option>
        <option data-country-code="+356" value="mt">Malta +356</option>
        <option data-country-code="+692" value="mh">Marshall Islands +692</option>
        <option data-country-code="+596" value="mq">Martinique +596</option>
        <option data-country-code="+222" value="mr">Mauritania (‫موريتانيا‬‎) +222</option>
        <option data-country-code="+230" value="mu">Mauritius (Moris) +230</option>
        <option data-country-code="+52" value="mx">Mexico (México) +52</option>
        <option data-country-code="+691" value="fm">Micronesia +691</option>
        <option data-country-code="+373" value="md">Moldova (Republica Moldova) +373</option>
        <option data-country-code="+377" value="mc">Monaco +377</option>
        <option data-country-code="+976" value="mn">Mongolia (Монгол) +976</option>
        <option data-country-code="+382" value="me">Montenegro (Crna Gora) +382</option>
        <option data-country-code="+1664" value="ms">Montserrat +1664</option>
        <option data-country-code="+212" value="ma">Morocco +212</option>
        <option data-country-code="+258" value="mz">Mozambique (Moçambique) +258</option>
        <option data-country-code="+95" value="mm">Myanmar (Burma) (မြန်မာ) +95</option>
        <option data-country-code="+264" value="na">Namibia (Namibië) +264</option>
        <option data-country-code="+674" value="nr">Nauru +674</option>
        <option data-country-code="+977" value="np">Nepal (नेपाल) +977</option>
        <option data-country-code="+31" value="nl">Netherlands (Nederland) +31</option>
        <option data-country-code="+687" value="nc">New Caledonia (Nouvelle-Calédonie) +687</option>
        <option data-country-code="+64" value="nz">New Zealand +64</option>
        <option data-country-code="+505" value="ni">Nicaragua +505</option>
        <option data-country-code="+227" value="ng">Niger (Nijar) +227</option>
        <option data-country-code="+234" value="ng">Nigeria +234</option>
        <option data-country-code="+683" value="nu">Niue +683</option>
        <option data-country-code="+6723" value="nf">Norfolk Island +6723</option>
        <option data-country-code="+1" value="mp">Northern Mariana Islands +1</option>
        <option data-country-code="+850" value="kp">North Korea (조선민주주의인민공화국) +850</option>
        <option data-country-code="+47" value="no">Norway (Norge) +47</option>
        <option data-country-code="+968" value="ro">Oman (‫عُمان‬‎) +968</option>
        <option data-country-code="+92" value="pk">Pakistan (‫پاکستان‬‎) +92</option>
        <option data-country-code="+680" value="pw">Palau +680</option>
        <option data-country-code="+970" value="ps">Palestine (‫فلسطين‬‎) +970</option>
        <option data-country-code="+507" value="pa">Panama (Panamá) +507</option>
        <option data-country-code="+675" value="pg">Papua New Guinea +675</option>
        <option data-country-code="+595" value="py">Paraguay +595</option>
        <option data-country-code="+51" value="pe">Peru (Perú) +51</option>
        <option data-country-code="+63" value="ph">Philippines +63</option>
        <option data-country-code="+48" value="pl">Poland (Polska) +48</option>
        <option data-country-code="+351" value="pt">Portugal +351</option>
        <option data-country-code="+1787" value="pr">Puerto Rico +1787</option>
        <option data-country-code="+974" value="qa">Qatar (‫قطر‬‎) +974</option>
        <option data-country-code="+262" value="re">Réunion (La Réunion) +262</option>
        <option data-country-code="+40" value="ro">Romania (România) +40</option>
        <option data-country-code="+7" value="ru">Russia (Россия) +7</option>
        <option data-country-code="+250" value="rw">Rwanda +250</option>
        <option data-country-code="+685" value="ws">Samoa +685</option>
        <option data-country-code="+378" value="sm">San Marino +378</option>
        <option data-country-code="+239" value="st">São Tomé &amp; Príncipe (São Tomé e Príncipe) +239</option>
        <option data-country-code="+966" value="sa">Saudi Arabia (‫المملكة العربية السعودية‬‎) +966</option>
        <option data-country-code="+221" value="sn">Senegal +221</option>
        <option data-country-code="+381" value="rs">Serbia (Србија) +381</option>
        <option data-country-code="+248" value="sc">Seychelles +248</option>
        <option data-country-code="+232" value="sl">Sierra Leone +232</option>
        <option data-country-code="+65" value="sg">Singapore +65</option>
        <option data-country-code="+1721" value="sx">Sint Maarten +1721</option>
        <option data-country-code="+421" value="sk">Slovakia (Slovensko) +421</option>
        <option data-country-code="+386" value="si">Slovenia (Slovenija) +386</option>
        <option data-country-code="+677" value="sb">Solomon Islands +677</option>
        <option data-country-code="+252" value="so">Somalia (Soomaaliya) +252</option>
        <option data-country-code="+27" value="za">South Africa +27</option>
        <option data-country-code="+82" value="kr">South Korea (대한민국) +82</option>
        <option data-country-code="+211" value="ss">South Sudan (‫جنوب السودان‬‎) +211</option>
        <option data-country-code="+34" value="es">Spain (España) +34</option>
        <option data-country-code="+94" value="lk">Sri Lanka (ශ්‍රී ලංකාව) +94</option>
        <option data-country-code="+590" value="bl">Saint Barthélemy (Saint-Barthélemy) +590</option>
        <option data-country-code="+290" value="sh">Saint Helena, Ascension &amp; Tristan da Cunha +290</option>
        <option data-country-code="+1869" value="kn">Saint Kitts &amp; Nevis +1869</option>
        <option data-country-code="+1758" value="lc">Saint Lucia +1758</option>
        <option data-country-code="+590" value="mf">Saint Martin (Saint-Martin) +590</option>
        <option data-country-code="+508" value="pm">Saint Pierre &amp; Miquelon (Saint-Pierre-et-Miquelon) +508</option>
        <option data-country-code="+1784" value="vc">Saint Vincent &amp; Grenadines +1784</option>
        <option data-country-code="+249" value="sd">Sudan (‫السودان‬‎) +249</option>
        <option data-country-code="+597" value="sr">Suriname +597</option>
        <option data-country-code="+268" value="sz">Swaziland +268</option>
        <option data-country-code="+46" value="se">Sweden (Sverige) +46</option>
        <option data-country-code="+41" value="ch">Switzerland (Schweiz) +41</option>
        <option data-country-code="+963" value="sy">Syria (‫سوريا‬‎) +963</option>
        <option data-country-code="+886" value="tw">Taiwan (台灣) +886</option>
        <option data-country-code="+992" value="tj">Tajikistan +992</option>
        <option data-country-code="+255" value="tz">Tanzania +255</option>
        <option data-country-code="+66" value="th">Thailand (ไทย) +66</option>
        <option data-country-code="+670" value="tl">Timor-Leste +670</option>
        <option data-country-code="+228" value="tg">Togo +228</option>
        <option data-country-code="+690" value="tk">Tokelau +690</option>
        <option data-country-code="+676" value="to">Tonga +676</option>
        <option data-country-code="+1868" value="tt">Trinidad &amp; Tobago +1868</option>
        <option data-country-code="+216" value="tn">Tunisia +216</option>
        <option data-country-code="+90" value="tr">Turkey (Türkiye) +90</option>
        <option data-country-code="+993" value="tm">Turkmenistan +993</option>
        <option data-country-code="+1649" value="tc">Turks &amp; Caicos Islands +1649</option>
        <option data-country-code="+688" value="tv">Tuvalu +688</option>
        <option data-country-code="+1340" value="vi">U.S. Virgin Islands +1340</option>
        <option data-country-code="+256" value="ug">Uganda +256</option>
        <option data-country-code="+380" value="ua">Ukraine (Україна) +380</option>
        <option data-country-code="+971" value="ae">United Arab Emirates (‫الإمارات العربية المتحدة‬‎) +971</option>
        <option data-country-code="+44" value="gb">United Kingdom +44</option>
        <option data-country-code="+1" value="us">United States +1</option>
        <option data-country-code="+598" value="uy">Uruguay +598</option>
        <option data-country-code="+998" value="uz">Uzbekistan (Oʻzbekiston) +998</option>
        <option data-country-code="+678" value="vu">Vanuatu +678</option>
        <option data-country-code="+379" value="va">Vatican City (Città del Vaticano) +379</option>
        <option data-country-code="+58" value="ve">Venezuela +58</option>
        <option data-country-code="+84" value="vn">Vietnam (Việt Nam) +84</option>
        <option data-country-code="+681" value="wf">Wallis &amp; Futuna +681</option>
        <option data-country-code="+967" value="ye">Yemen (‫اليمن‬‎) +967</option>
        <option data-country-code="+260" value="zm">Zambia +260</option>
        <option data-country-code="+263" value="zw">Zimbabwe +263</option>
    </select>
