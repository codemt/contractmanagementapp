<?php $__env->startSection('page-content'); ?>

<div class="title-bar">
	<h1 class="title-bar-title">
		<span class="d-ib">Stock Report</span>
	</h1>
</div>
<div class="row gutter-xs">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header bg-primary">
				<div class="card-actions">
					<button type="button" class="card-action card-toggler" title="Collapse"></button>
					<button type="button" class="card-action card-reload" title="Reload"></button>
				</div>
				<strong>Product Purchase History</strong>
			</div>
			<div class="card-body">
				<table id="demo-datatables-5" class="table table-striped table-nowrap dataTable" cellspacing="0" width="100%">
					<thead>
						<tr>
							<th>#</th>
							<th>Product Name</th>
							<th>quantity</th>
							<th>Purchased Date</th>
						</tr>
					</thead>
					<tbody>
						<?php if(isset($products)): ?>
						<?php for($i=0;$i< count($products) ;$i++): ?>
						<tr>
							<td><?php echo e($i+1); ?></td>
							<td><?php echo e($products[$i]->productStock->name); ?></td>
							<td><?php echo e($products[$i]->quantity); ?></td>
							<td><?php echo e($products[$i]->created_at->format('d-m-Y')); ?></td>
						</tr>
						<?php endfor; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>