

<?php $__env->startSection('page-content'); ?>


<div class="title-bar">
	<h1 class="title-bar-title">
		<span class="d-ib">Direct Buyers</span>
	</h1>
</div>
<div class="row gutter-xs">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header bg-primary">
				<div class="card-actions">
					<a href="<?php echo e(route ('stock.add_stock')); ?>"><button type="button" class="btn btn-xs btn-primary"  title="Add Stock">
						<i class="icon icon-plus-circle icon-lg"></i> Add Stock
					</button></a>
				</div>
				<strong>Direct Buyers</strong>
			</div>
			<div class="card-body">
				<table id="demo-datatables-5" class="table table-striped table-nowrap dataTable" cellspacing="0" width="100%">
					<thead>
						<tr>
							<th>#</th>
							<th>Form No</th>
							<th>Name</th>
							<th>Mobile</th>
							<th>Email</th>
							<th>Date</th>
							<th>Description</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php if(isset($buyers)): ?>
						<?php $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($loop->iteration); ?></td>
							<td><?php echo e($buyer->form_no); ?></td>
							<td><?php echo e($buyer->name); ?></td>
							<td><?php echo e($buyer->mobile); ?></td>
							<td><?php echo e($buyer->email); ?></td>
							<td><?php echo e($buyer->sold_date); ?></td>
							<td><?php echo e($buyer->description); ?></td>
							
							<td>
								<a href="<?php echo e(route('stock.direct_deduct_report',$buyer->id)); ?>" class="btn btn-xs btn-outline-success" data-toggle="tooltip" title="View Report" target="_blank">
                                            <i class="icon icon-eye"></i>
                                        </a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>