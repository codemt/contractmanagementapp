<?php $__env->startSection('page-content'); ?>
    <div class="title-bar">
        <h1 class="title-bar-title">
            <span class="d-ib">Tested Product</span>
        </h1>
    </div>
    <div class="row gutter-xs">
        <div class="col-xs-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-actions">
                        <button type="button" class="card-action card-toggler" title="Collapse"></button>
                        <button type="button" class="card-action card-reload" title="Reload"></button>
                    </div>
                    <strong>List Of Test Product</strong>
                </div>
                <div class="card-body">
                    <table id="demo-datatables-5" class="table table-striped table-nowrap dataTable" cellspacing="0" width="100%">
                        <thead>

                            <tr>
                                <th>Contract No.</th>
                                <th>Client Name</th>
                                <th>technician Name</th>
                                <th>stock Name</th>
                                <th>Control Type</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                    <td><?php echo e($contract->id); ?></td>
                                    <td><?php echo e($contract->contract->user->name ?? ''); ?></td>
                                    <td><?php echo e($contract->technician->name ?? ''); ?></td>
                                    <td><?php echo e($contract->stock->name ?? ''); ?></td>
                                    <td><?php echo e($contract->control_type ?? ''); ?></td>
                                    <td>
                                    <a href="<?php echo e(route('supervisor.testedProductPdf',[$contract->id])); ?>" class="btn btn-xs btn-outline-primary" title="Test Result" target="_blank">
                                            <i class="icon icon-eye"></i> Test Result</a>
                                        <a href="<?php echo e(route('supervisor.assignStock.completed',[$contract->id])); ?>">
                                        <button class="btn btn-xs btn-outline-primary"  type="button" data-toggle="tooltip" title="Assign Stock">
                                            <i class="icon icon-check"></i> Complete
                                        </button></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php echo $__env->make('modals.technician', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('modals.tester_report', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>