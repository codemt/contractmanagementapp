<?php $__env->startSection('content'); ?>

<h3 class="login-heading">Stock</h3>
<div class="login-form">

    <form data-toggle="md-validator"  method="POST" action="<?php echo e(route('stock.login')); ?>">
        <?php echo e(csrf_field()); ?>

        

        <?php if($errors->has('email')): ?>
        <span class="text-primary">
            <strong><?php echo e($errors->first('email')); ?></strong>
        </span>
        <?php endif; ?>

        <?php if($errors->has('password')): ?>
        <span class="text-primary">
            <strong><?php echo e($errors->first('password')); ?></strong>
        </span>
        <?php endif; ?>

        <div class="md-form-group md-label-static<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <input class="md-form-control" type="email" name="email" value="<?php echo e(old('email')); ?>" spellcheck="false" autocomplete="off" data-msg-required="Please enter your email address." required>
            <label class="md-control-label">Enter Email Address</label>
        </div>


        <div class="md-form-group md-label-static<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <input class="md-form-control" type="password" name="password" minlength="6" data-msg-minlength="Password must be 6 characters or more." data-msg-required="Please enter your password." required>
            <label class="md-control-label">Enter Password</label>
        </div>


        <div class="md-form-group md-custom-controls">
            <label class="custom-control custom-control-primary custom-checkbox">
                <input class="custom-control-input" type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                <span class="custom-control-indicator"></span>
                <span class="custom-control-label">Keep me signed in</span>
            </label>
            <span aria-hidden="true"> · </span>
            <a href="<?php echo e(route('stock.password.reset')); ?>">Forgot password?</a>
        </div>
        <button class="btn btn-primary btn-block" type="submit">Sign in</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>