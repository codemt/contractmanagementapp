<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php echo $__env->make('_partials.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldPushContent('page-style'); ?>
</head>
<body class="layout layout-header-fixed">
    <div class="layout-header">
        <?php echo $__env->make('_partials.top_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="layout-main">
        <div class="layout-sidebar">
            <div class="layout-sidebar-backdrop"></div>
            <div class="layout-sidebar-body">
                <?php echo $__env->make('_partials.side_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="layout-content">
            <div class="layout-content-body">
                <?php echo $__env->yieldContent('page-content'); ?>
            </div>
        </div>
        <?php echo $__env->make('_partials.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('_partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <?php echo $__env->yieldContent('modals'); ?>
    <?php echo $__env->make('_partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldPushContent('page-script'); ?>
</body>
</html>
