<div id="change_technician" role="dialog" class="modal in">
    <div class="modal-dialog modal-md">
        <div class="modal-content animated bounceInDown">
            <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">×</span>
                    <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title">Change Technician</h4>
            </div>
             <form  action="<?php echo e(route('supervisor.change_technician')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

            <div class="modal-body">
                  <div class="form-group">
                    <label for="tester" class="col-form-label">Select Technician:</label>
                    <input type="hidden" name="id" value="">
                    <select class="form-control col-sm-4" id="tester" name="technician_id" required>
                        
                        <?php $__currentLoopData = $technicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($technician->id); ?>"><?php echo e($technician->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
             
            <div class="modal-footer">
                <button class="btn btn-primary"type="submit">
                    <i class="icon icon-check-circle"></i> Submit
                </button>
                <button class="btn btn-default" data-dismiss="modal" type="button">
                    <i class="icon icon-times-circle"></i> Cancel
                </button>
                </form>
            </div>
        </div>
    </div>
</div>
