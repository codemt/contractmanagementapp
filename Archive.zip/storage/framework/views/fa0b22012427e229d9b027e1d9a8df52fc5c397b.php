<?php $__env->startSection('content'); ?>
<h3 class="login-heading">Reset Password</h3>
<div class="login-form">
    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    <form data-toggle="md-validator" method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo e(csrf_field()); ?>


        <div class="md-form-group md-label-static<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
          <input class="md-form-control" type="email" name="email"  spellcheck="false" autocomplete="off" data-msg-required="Please enter your email address." required>
          <label class="md-control-label">Email address</label>
          <span class="md-help-block">We'll send you an reset link.</span>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Send password reset link</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>