<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="theme-color" content="#d9230f">

<link rel="icon" type="image/png" href="<?php echo e(asset('favicon.ico')); ?>">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400italic,500,700">

<link rel="stylesheet" href="<?php echo e(asset('css/vendor.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/elevator.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/application.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/parsley_validation.css')); ?>">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

