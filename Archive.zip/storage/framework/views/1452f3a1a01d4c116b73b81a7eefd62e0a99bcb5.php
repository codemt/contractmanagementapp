

<?php $__env->startSection('page-content'); ?>


<div class="title-bar">
	<h1 class="title-bar-title">
		<span class="d-ib">Return Replace Scrap</span>
	</h1>
</div>
<div class="row gutter-xs">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header bg-primary">
				<div class="card-actions">
					<a href="<?php echo e(route ('stock.replace-return')); ?>"><button type="button" class="btn btn-xs btn-primary"  title="Add Stock">
						<i class="icon icon-plus-circle icon-lg"></i> Add New
					</button></a>
				</div>
				<strong>List</strong>
			</div>
			<div class="card-body">
				<table id="demo-datatables-5" class="table table-striped table-nowrap dataTable" cellspacing="0" width="100%">
					<thead>
						<tr>
							<th>#</th>
							<th>Form No</th>
							<th>Type</th>
							<th>Name</th>
							<th>Mobile</th>
							<th>Email</th>
							<th>Controller No</th>
							<th>Technician Name</th>
							<th>Date</th>
							<th>Description</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php if(isset($clients)): ?>
						<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($loop->iteration); ?></td>
							<td><?php echo e($client->form_no); ?></td>
							<td><?php echo e($client->type); ?></td>
							<td><?php echo e($client->name); ?></td>
							<td><?php echo e($client->mobile); ?></td>
							<td><?php echo e($client->email); ?></td>
							<td><?php echo e($client->controller_no); ?></td>
							<td><?php echo e($client->technician()); ?></td>
							<td><?php echo e(\Carbon\Carbon::parse($client->date)->format('d-m-Y')); ?></td>
							<td><?php echo e($client->description); ?></td>
							
							<td>
								<a href="<?php echo e(route('stock.return_replace_report',$client->id)); ?>" class="btn btn-xs btn-outline-success" data-toggle="tooltip" title="View Report" target="_blank">
                                            <i class="icon icon-eye"></i>
                                        </a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>