<?php $__env->startSection('page-content'); ?>
    <div class="title-bar">
        <h1 class="title-bar-title">
            <span class="d-ib">Testing</span>
        </h1>
    </div>
    <div class="row gutter-xs">
        <div class="col-xs-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-actions">
                        <button type="button" class="card-action card-toggler" title="Collapse"></button>
                        <button type="button" class="card-action card-reload" title="Reload"></button>
                    </div>
                    <strong>New Products To Testing</strong>
                </div>
                <div class="card-body">
                    <table id="demo-datatables-5" class="table table-striped table-nowrap dataTable" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Sr No.</th>
                                <th>Contract No.</th>
                                <th>Control Type</th>
                                <th>Due Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php if(isset($testProducts)): ?>
                            <?php $__currentLoopData = $testProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($product->contract->id); ?></td>
                            <td><?php echo e($product->contract->detail->control_type); ?></td>
                            <td><?php echo e($product->due_date); ?></td>
                            <td>
                                <a href="<?php echo e(route('technician.test_product',$product->id)); ?>" class="btn btn-xs btn-outline-primary">
                                    <i class="icon icon-check"></i> Test Product
                                </a>
                            </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> <!-- end normal control testing -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>