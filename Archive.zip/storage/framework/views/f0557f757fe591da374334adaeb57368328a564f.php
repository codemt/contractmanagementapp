<?php $__env->startSection('page-content'); ?>
    <div class="title-bar">
        <h1 class="title-bar-title">
            <span class="d-ib">All Contract</span>
        </h1>
    </div>
    <div class="row gutter-xs">
        <div class="col-xs-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-actions">
                        <button type="button" class="card-action card-toggler" title="Collapse"></button>
                        <button type="button" class="card-action card-reload" title="Reload"></button>
                    </div>
                    <strong>Pending Contract</strong>
                </div>
                <div class="card-body">
                    <table id="demo-datatables-5" class="table table-striped table-bordered table-nowrap dataTable" cellspacing="0" width="100%">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Contract No.</th>
                            <th>Contract Date</th>
                            <th>Control Type</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(isset($contracts)): ?>
                        <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($contract->id); ?></td>
                                <td><?php echo e($contract->created_at->format('d-m-Y')); ?></td>
                                <td><?php echo e($contract->detail->control_type); ?></td>

                                <td>
                                    <a href="<?php echo e(route('contract.edit',[$contract->id])); ?>" class="btn btn-xs btn-outline-warning" data-toggle="tooltip" title="Edit Contract">
                                        <i class="icon icon-edit"></i>
                                    </a>
                                     <a href="<?php echo e(route('contractPdf',[$contract->id])); ?>" target="_blank">
                                    <button type="button" class="btn btn-xs btn-outline-primary" data-toggle="tooltip" title="View Contract">
                                        <i class="icon icon-eye"></i>
                                    </button></a>


                                        <a href="javascript:;" data-contract_id=<?php echo e($contract->id); ?>" class="deleteContract">
                                    <button type="button" class="btn btn-xs btn-outline-primary" data-toggle="tooltip" title="Delete Contract">
                                        <i class="icon icon-trash"></i>
                                    </button></a>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-script'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
<script type="text/javascript">

    // server side processing datatable
    // $(document).ready( function () {
    //     $('#demo-datatables-5').DataTable({
            
    //         "processing": true,
    //         "bDestroy": true,
    //         "serverSide": true,
    //         "pageLength":5,
    //         "ajax":{
    //                  "url": "<?php echo e(route('clientContract')); ?>",
    //                  "dataType": "json",
    //                  "type": "POST",
    //                  "data":{ _token: "<?php echo e(csrf_token()); ?>"}
    //                },
    //         "columns": [
    //             { "data": "contract_no" },
    //             { "data": "contract_date" },
    //             { "data": "control_type" },
    //             { "data": "action" }
    //         ]    
    //     });
    // });

    //delete contract
    $(document).on('click','.deleteContract',function(){
        let contract_id = $(this).data('contract_id');
            swal({
            title: "Are you sure?",
            text: "You will not be able to recover this contract!",
            icon: "warning",
            buttons: {
            cancel: true,
            confirm: true,
            },
             dangerMode: true,
        }).
        then((value) => {
           if (value) {
            $.ajax({
                url: "/contract/"+contract_id,
                type: "POST",
                data: {_method:'delete'},
                dataType: "html",
                success: function (response) {
                    console.log(response);
                    swal("Done!","It was succesfully deleted!","success");
                   location.reload();
                    
                }
            });
          }
       });
    })

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>