<?php $__env->startSection('content'); ?>
<h3 class="login-heading">Client Register</h3>
<div class="login-form">
    <form data-toggle="md-validator"  method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo e(csrf_field()); ?>

        
        <?php if($errors->has('name')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('name')); ?></strong>
        </span>
        <?php endif; ?>

        <?php if($errors->has('email')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('email')); ?></strong>
        </span>
        <?php endif; ?>

        <?php if($errors->has('phone')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('phone')); ?></strong>
        </span>
        <?php endif; ?>

        <?php if($errors->has('password')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('password')); ?></strong>
        </span>
        <?php endif; ?>

        <div class="md-form-group md-label-static<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
            <input class="md-form-control" type="text" name="name" value="<?php echo e(old('name')); ?>" spellcheck="false" autocomplete="off" data-msg-required="Please enter your name." required>
            <label class="md-control-label">Enter Name</label>
        </div>

        <div class="md-form-group md-label-static<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <input class="md-form-control" type="email" name="email" value="<?php echo e(old('email')); ?>" spellcheck="false" autocomplete="off" data-msg-required="Please enter your email." required autocomplete="off">
            <label class="md-control-label">Enter Email Address</label>
        </div>

        <div class="md-form-group md-label-static<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
            <input class="md-form-control" type="text" name="phone" value="<?php echo e(old('phone')); ?>" spellcheck="false" autocomplete="off" data-msg-required="Please enter your contact no.." required>
            <label class="md-control-label">Enter Contact No.</label>
        </div>

        <div class="md-form-group md-label-static<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <input class="md-form-control" type="password" name="password" value="<?php echo e(old('password')); ?>" spellcheck="false" autocomplete="off" data-msg-required="Please enter pasword" required>
            <label class="md-control-label">Passwod</label>
        </div>

        <div class="md-form-group md-label-static">
            <input class="md-form-control" type="password" name="password_confirmation" id="password-confirm" required>
            <label class="md-control-label">Confirm Password</label>
        </div>

        <button class="btn btn-primary btn-block" type="submit">Register</button>
        <center><a href="<?php echo e(route('login')); ?>">Already have an account</a></center>

    </form>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>