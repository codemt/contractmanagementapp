<?php

namespace App\Http\Controllers;

use App\TestingType;
use Illuminate\Http\Request;

class TestingTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TestingType  $testingType
     * @return \Illuminate\Http\Response
     */
    public function show(TestingType $testingType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TestingType  $testingType
     * @return \Illuminate\Http\Response
     */
    public function edit(TestingType $testingType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TestingType  $testingType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TestingType $testingType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TestingType  $testingType
     * @return \Illuminate\Http\Response
     */
    public function destroy(TestingType $testingType)
    {
        //
    }
}
