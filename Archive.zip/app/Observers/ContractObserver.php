<?php

namespace App\Observers;
use App\ContractDetail;

class ContractObserver
{
    public function created(ContractDetail $contract)
    {
     
    }
}